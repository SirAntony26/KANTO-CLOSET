
const cart = [];

function addToCart(name, price) {
  cart.push({ name, price });
  renderCart();
}

function renderCart() {
  const items = document.getElementById('cart-items');
  const total = document.getElementById('cart-total');
  let t = 0;
  items.innerHTML = '';
  cart.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.name} - KSh ${item.price}`;
    items.appendChild(li);
    t += item.price;
  });
  total.textContent = t;
}

function calculateDelivery() {
  const town = document.getElementById('town').value;
  let distance = 0;
  if (town === "Nairobi") distance = 85;
  else if (town === "Muranga Town") distance = 0;
  else if (town === "Maua Town") distance = 190;
  document.getElementById('delivery-cost').textContent = distance;
}

function payWithMpesa() {
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const delivery = parseInt(document.getElementById('delivery-cost').textContent);
  const name = document.getElementById('name').value;
  const phone = document.getElementById('phone').value;
  const address = document.getElementById('address').value;

  if (!name || !phone || !address || delivery === 0) {
    alert("Please complete the checkout form and calculate delivery first.");
    return;
  }

  const fullTotal = total + delivery;
  alert(`Pay KSh ${fullTotal} via M-Pesa:
1. Go to M-Pesa
2. Lipa na M-Pesa
3. Buy Goods & Services
4. Till No: 3446190
5. Amount: ${fullTotal}`);

  const message = `Hi, I paid KSh ${fullTotal} for my Kanto Closet order. Name: ${name}, Phone: ${phone}, Address: ${address}`;
  window.open(`https://wa.me/254740113715?text=${encodeURIComponent(message)}`, '_blank');
}
